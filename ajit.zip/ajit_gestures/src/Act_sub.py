#!/usr/bin/env python
import rospy
import sys
from std_msgs.msg import String
from std_msgs.msg import Int32
#sys.path.append('~/ajit_ws/src/dynamixel_workbench_msgs/msg')
#sys.path.append('~/ajit_ws/src/dynamixel_workbench_msgs/msg')

from dynamixel_workbench_msgs.msg import DynamixelStateList
from dynamixel_workbench_msgs.srv import DynamixelCommand,DynamixelCommandRequest
Ajit_Pose_client=rospy.ServiceProxy('/dynamixel_workbech/dynamixel_command',DynamixelCommand)

gesture=0

def AjitCallback(info):
	global gesture
	gesture=info.data
	print(gesture)

def command(m_id,val):
	Ajit_Pose=DynamixelCommandRequest()
	Ajit_Pose.id=m_id
	Ajit_Pose.addr_name='Goal_Position'
	Ajit_Pose.value=val
	a=Ajit_Pose_client(Ajit_Pose)
def Namaste():
	l=[(10,),(11,),(12,),(13,),(14,),(20,),(21,),(22,),(23,),(24,)]
 	for i in l:
		command(i[0],i[1])
def Handshake():
	l=[(10,),(11,),(12,),(13,),(14,),(20,),(21,),(22,),(23,),(24,)]
 	for i in l:
		 command(i[0],i[1])
def Hi():
	l=[(10,),(11,),(12,),(13,),(14,),(20,),(21,),(22,),(23,),(24,)]
 	for i in l:
	    	command(i[0],i[1])
def Dab():
	l=[(10,),(11,),(12,),(13,),(14,),(20,),(21,),(22,),(23,),(24,)]
 	for i in l:
	    	command(i[0],i[1])
def Defence():
	l=[(10,),(11,),(12,),(13,),(14,),(20,),(21,),(22,),(23,),(24,)]
 	for i in l:
	    	command(i[0],i[1])

if __name__=='__main__':
	try:
		while not rospy.is_shutdown():
        		rospy.init_node('Gesture_sub',anonymous=True)
        		rospy.Subscriber('/Gesture_Info',Int32,AjitCallback)
			#rospy.spin()
        		if gesture==1:
	    			print('Executing Namaste')
            			#Namaste()
            			rospy.sleep(2)
        		elif gesture==2:
	    			print('Executing Handshake')
            			#Handshake()
            			rospy.sleep(2)
        		elif gesture==3:
				print('Executing Hi')
            			#Hi()
            			rospy.sleep(2)
        		elif gesture==4:
				print('Executing adaab')
            			#adaab()
            			rospy.sleep(2)
        		elif gesture==5:
				print('Executing Defence')
            			#Defence()
            			rospy.sleep(2)
			else:
				print('Going to home position')
	    			#Safe()
	    			rospy.sleep(2)
		#rospy.spin()
    	except:
        	pass
